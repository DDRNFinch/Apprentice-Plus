GDPR Update

Add:
1. privacy-notice.html to your About/Settings page.
2. Include clear-data.js.
3. Place clear-data-button.html in Settings/About.

This adds:
- Privacy notice
- Clear local data button
- Local storage erase function
