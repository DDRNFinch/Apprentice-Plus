function clearAllApprenticeData(){
 if(confirm('Delete all locally stored Apprentice+ data from this device?')){
   localStorage.clear();
   alert('All local Apprentice+ data has been removed.');
   location.reload();
 }
}